# wkhtmltopdf Puppet Module for Boxen

## Usage

```puppet
include wkhtmltopdf
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
